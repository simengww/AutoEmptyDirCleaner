#!/system/bin/sh

# 设置模块路径
MODDIR=${0%/*}
LOG_FILE="$MODDIR/clean.log"

# 确保必要目录存在
mkdir -p /data/cron
mkdir -p /data/adb/modules/AutoEmptyDirCleaner

# 查找或安装busybox
find_busybox() {
    if [ -f /data/adb/magisk/busybox ]; then
        echo "/data/adb/magisk/busybox"
        return 0
    elif [ -f /data/adb/ksu/bin/busybox ]; then
        echo "/data/adb/ksu/bin/busybox"
        return 0
    elif [ -x /system/xbin/busybox ]; then
        echo "/system/xbin/busybox"
        return 0
    elif [ -x /system/bin/busybox ]; then
        echo "/system/bin/busybox"
        return 0
    fi
    return 1
}

install_busybox() {
    # 下载并安装Magisk的busybox模块
    TEMP_DIR="/data/local/tmp"
    BUSYBOX_ZIP="$TEMP_DIR/busybox.zip"
    
    # 使用wget或curl下载busybox模块
    if command -v wget >/dev/null; then
        wget -O "$BUSYBOX_ZIP" "https://github.com/Magisk-Modules-Repo/busybox-ndk/releases/latest/download/busybox-ndk.zip"
    elif command -v curl >/dev/null; then
        curl -L -o "$BUSYBOX_ZIP" "https://github.com/Magisk-Modules-Repo/busybox-ndk/releases/latest/download/busybox-ndk.zip"
    else
        echo "$(date "+%Y-%m-%d %H:%M:%S") 错误：无法下载busybox" >> "$LOG_FILE"
        return 1
    fi
    
    # 安装模块
    if [ -f "$BUSYBOX_ZIP" ]; then
        /data/adb/magisk/magisk --install-module "$BUSYBOX_ZIP"
        rm -f "$BUSYBOX_ZIP"
        echo "$(date "+%Y-%m-%d %H:%M:%S") Busybox已安装，请重启设备" >> "$LOG_FILE"
        return 0
    fi
    return 1
}

# 获取busybox路径
BUSYBOX=$(find_busybox)
if [ $? -ne 0 ]; then
    echo "$(date "+%Y-%m-%d %H:%M:%S") 未找到busybox，尝试安装..." >> "$LOG_FILE"
    install_busybox
    exit 1
fi

# 创建crontab文件
echo "0 4 * * * /system/bin/clean_empty_dirs.sh" > /data/cron/root

# 授予执行权限
chmod 0755 $MODDIR/system/bin/clean_empty_dirs.sh
chmod 0755 $MODDIR/system/bin/stats.sh
chmod 0644 /data/cron/root

# 停止已存在的crond进程
$BUSYBOX pkill crond

# 启动crond服务
$BUSYBOX crond -b -c /data/cron

# 检查crond是否成功启动
if ! $BUSYBOX pgrep crond >/dev/null; then
    echo "$(date "+%Y-%m-%d %H:%M:%S") Crond启动失败" >> "$LOG_FILE"
else
    echo "$(date "+%Y-%m-%d %H:%M:%S") Crond启动成功" >> "$LOG_FILE"
fi