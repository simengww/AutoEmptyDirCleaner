#!/system/bin/sh

# 设置模块路径
MODDIR=${0%/*}
LOG_FILE="$MODDIR/clean.log"

# 确保必要目录存在
mkdir -p /data/cron
mkdir -p /data/adb/modules/AutoEmptyDirCleaner

# 寻找可用的busybox
if [ -f /data/adb/magisk/busybox ]; then
    BUSYBOX="/data/adb/magisk/busybox"
elif [ -f /data/adb/ksu/bin/busybox ]; then
    BUSYBOX="/data/adb/ksu/bin/busybox"
else
    echo "$(date "+%Y-%m-%d %H:%M:%S") 错误：未找到busybox" >> "$LOG_FILE"
    exit 1
fi

# 创建crontab文件
echo "0 4 * * * /system/bin/clean_empty_dirs.sh" > /data/cron/root

# 授予执行权限
chmod 0755 $MODDIR/system/bin/clean_empty_dirs.sh
chmod 0644 /data/cron/root

# 停止已存在的crond进程
$BUSYBOX pkill crond

# 启动crond服务
$BUSYBOX crond -b -c /data/cron

# 检查crond是否成功启动
if ! $BUSYBOX pgrep crond >/dev/null; then
    echo "$(date "+%Y-%m-%d %H:%M:%S") Crond启动失败" >> "$LOG_FILE"
else
    echo "$(date "+%Y-%m-%d %H:%M:%S") Crond启动成功" >> "$LOG_FILE"
fi