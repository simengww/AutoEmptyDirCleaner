# 清理空文件(夹)，应用缓存

## 版本 2.0 重大更新
- 添加统计功能
  - 记录总运行次数
  - 记录总清理文件夹数量
  - 记录最后运行时间
  - 统计信息保存在`stats.txt`文件中
- 自动安装busybox
  - 自动检测系统是否安装busybox
  - 支持自动下载安装busybox模块
  - 支持curl和wget两种下载方式
- 改进日志记录
  - 添加错误日志文件
  - 优化日志格式
  - 添加时间戳
  - 自动清理过大的日志文件
- 优化错误处理
  - 更好的错误提示
  - 防止关键文件缺失导致崩溃

## 使用说明
1. 安装模块后会自动检查并安装busybox（如需要）
2. 模块在每天早上7点自动运行
3. 统计信息在每次运行后自动更新
4. 可在Magisk Manager中查看最新统计信息
5. 日志保存在`/data/adb/modules/AutoEmptyDirCleaner_WG/log/`目录下
6. 白名单配置文件位于`/data/adb/modules/AutoEmptyDirCleaner_WG/notclear.conf`

## 注意事项
- 需要网络权限才能自动下载安装busybox
- 如果自动安装busybox失败，请手动安装
- 所有错误信息记录在error.log中

## 历史版本更新记录

## 版本 1.0 
未集成BusyBox,清除1KB的文件夹，或者清除小于1KB的空文件夹