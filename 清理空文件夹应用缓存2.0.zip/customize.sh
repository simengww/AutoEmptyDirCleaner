SKIPMOUNT=false

# 检查并安装busybox
check_busybox() {
    if [ ! -f "/data/adb/magisk/busybox" ]; then
        ui_print "- 未检测到busybox，尝试安装..."
        TEMP_DIR=/data/local/tmp
        BUSYBOX_ZIP="$TEMP_DIR/busybox.zip"
        
        if command -v curl >/dev/null 2>&1; then
            curl -L -o "$BUSYBOX_ZIP" "https://github.com/Magisk-Modules-Repo/busybox-ndk/releases/latest/download/busybox-ndk.zip"
        elif command -v wget >/dev/null 2>&1; then
            wget -O "$BUSYBOX_ZIP" "https://github.com/Magisk-Modules-Repo/busybox-ndk/releases/latest/download/busybox-ndk.zip"
        else
            ui_print "! 无法下载busybox，请手动安装busybox模块"
            return 1
        fi
        
        if [ -f "$BUSYBOX_ZIP" ]; then
            ui_print "- 正在安装busybox模块..."
            magisk --install-module "$BUSYBOX_ZIP"
            rm -f "$BUSYBOX_ZIP"
            ui_print "- busybox安装完成"
        else
            ui_print "! busybox下载失败，请手动安装busybox模块"
            return 1
        fi
    fi
    return 0
}

# 设置权限
set_permissions() {
    set_perm_recursive $MODPATH 0 0 0755 0644
    set_perm_recursive $MODPATH/crond 0 0 0755 0755
    set_perm $MODPATH/crond/clear.sh 0 0 0755
    set_perm $MODPATH/crond/stats.sh 0 0 0755
}

# 加载配置文件
key_source(){
    if test -e "$1" ;then
        source "$1"
        rm -rf "$1"
    fi
}

key_source $MODPATH/key.sh
key_source $MODPATH/busybox.sh

# 检查并安装busybox
check_busybox

# 创建必要的目录
mkdir -p $MODPATH/log

# 设置权限
set_permissions

# 初始化统计文件
if [ ! -f "$MODPATH/stats.txt" ]; then
    echo "总运行次数=0" > "$MODPATH/stats.txt"
    echo "总清理文件夹数量=0" >> "$MODPATH/stats.txt"
    echo "最后运行时间=从未运行" >> "$MODPATH/stats.txt"
fi

ui_print "- 安装完成"
ui_print "- 模块将在每天早上7点自动运行"
ui_print "- 统计信息将在运行后更新"
ui_print "- 日志文件位于：$MODPATH/log/"
ui_print "- 白名单配置文件：$MODPATH/notclear.conf"

