#!/system/bin/sh

# 停止crond服务
pkill crond

# 删除统计文件
rm -rf /data/adb/modules/AutoEmptyDirCleaner_WG/stats.txt

# 删除日志文件
rm -rf /data/adb/modules/AutoEmptyDirCleaner_WG/log

# 输出卸载信息
ui_print() {
  echo "$1"
}

ui_print "- 正在卸载清理空文件夹模块..."
ui_print "- 已停止定时任务服务"
ui_print "- 已清理模块数据和日志"
ui_print "- 卸载完成" 