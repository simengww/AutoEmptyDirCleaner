#!/system/bin/sh

STATS_FILE="$MODPATH/stats.txt"
LOG_FILE="$MODPATH/log/total.log"

# 初始化统计文件
init_stats() {
    if [ ! -f "$STATS_FILE" ]; then
        echo "总运行次数=0" > "$STATS_FILE"
        echo "总清理文件夹数量=0" >> "$STATS_FILE"
        echo "最后运行时间=从未运行" >> "$STATS_FILE"
    fi
}

# 更新统计信息
update_stats() {
    # 读取当前统计数据
    local current_runs=$(grep "总运行次数=" "$STATS_FILE" | cut -d'=' -f2)
    local current_dirs=$(grep "总清理文件夹数量=" "$STATS_FILE" | cut -d'=' -f2)
    
    # 更新运行次数
    current_runs=$((current_runs + 1))
    
    # 从日志中获取本次清理的文件夹数量
    local new_dirs=0
    if [ -f "$LOG_FILE" ]; then
        new_dirs=$(grep "共清理空文件夹" "$LOG_FILE" | tail -n 1 | grep -o '[0-9]*个' | head -n 1 | tr -d '个')
        new_dirs=${new_dirs:-0}
    fi
    
    # 更新总清理数量
    current_dirs=$((current_dirs + new_dirs))
    
    # 更新统计文件
    sed -i "s/总运行次数=.*/总运行次数=$current_runs/" "$STATS_FILE"
    sed -i "s/总清理文件夹数量=.*/总清理文件夹数量=$current_dirs/" "$STATS_FILE"
    sed -i "s/最后运行时间=.*/最后运行时间=$(date '+%Y-%m-%d %H:%M:%S')/" "$STATS_FILE"
    
    # 更新模块描述
    update_module_description
}

# 更新模块描述
update_module_description() {
    local stats=$(cat "$STATS_FILE")
    local description="统计信息：\n${stats}\n详细日志请查看：/data/adb/modules/AutoEmptyDirCleaner_WG/log/total.log"
    sed -i "s/description=.*/description=$description/" "$MODPATH/module.prop"
}

# 主函数
main() {
    init_stats
    update_stats
}

main 