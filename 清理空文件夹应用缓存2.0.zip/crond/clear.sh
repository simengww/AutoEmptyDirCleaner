#/system/bin/sh

# 确保MODPATH存在
test "$MODPATH" = "" && {
	echo "错误：MODPATH未设置"
	exit 1
}

# 创建必要的目录
mkdir -p $MODPATH/log

# 初始化日志文件
LOG_FILE="$MODPATH/log/total.log"
ERROR_LOG="$MODPATH/log/error.log"

# 错误处理函数
handle_error() {
	local error_msg="$1"
	echo "[$(date '+%Y-%m-%d %H:%M:%S')] 错误: $error_msg" >> "$ERROR_LOG"
	echo "$error_msg"
}

oldsize=$(du -sm /data | tr -cd '[0-9]')

function limitlog() {
	local logfile=$1
	local maxsize=$((1024 * 1000))
	filesize=$(ls -l $logfile 2>/dev/null | awk '{ print $5 }')
	if test $filesize -gt $maxsize; then
		echo " " > $logfile
	fi
}

function whitelist() {
	local file=$MODPATH/notclear.conf
	if [ ! -f "$file" ]; then
		handle_error "找不到白名单配置文件"
		return 1
	fi
	cat $file | sed '/^#/d;/^[[:space:]]*$/d' | sed ':a;N;$!ba;s/\n/|/g'
}

function clear_emptydir() {
	find /data/media -type d -empty 2>/dev/null | while read emptydir; do
		if test "$(echo "$emptydir" | grep -w -E "$(whitelist)")" != ""; then
			echo "跳过清理$emptydir"
			continue
		else
			rm -rf "${emptydir}" 2>/dev/null || handle_error "无法删除目录: ${emptydir}"
			echo "${emptydir}" >> $MODPATH/log/emptydir.log
		fi
	done
}

function clear_cachedir() {
	find /data/user* /data/data /data/media/*[0-9]*/Android -iname "*cache*" -type d 2>/dev/null | while read cachedir; do
		if test "$(echo "$cachedir" | grep -w -E "$(whitelist)")" != ""; then
			echo "跳过清理$cachedir"
			continue
		else
			rm -rf "${cachedir}" 2>/dev/null || handle_error "无法删除缓存目录: ${cachedir}"
			echo "${cachedir}" >> $MODPATH/log/cachedir.log
		fi
	done
}

function sort_uniq_log() {
	modlog=$(find $MODPATH -type f -iname "*.log" 2>/dev/null)
	for i in $modlog; do
		echo "$(sort $i | uniq)" > "$i"
	done
}

function clear_mod_log() {
	modlog=$(find $MODPATH -type f -iname "*.log" 2>/dev/null)
	for i in $modlog; do
		limitlog $i
	done
}

# 运行主要脚本
clear_emptydir 2>/dev/null
clear_cachedir 2>/dev/null
sort_uniq_log 2>/dev/null
clear_mod_log 2>/dev/null

a=$(cat $MODPATH/log/emptydir.log | sed '/^[[:space:]]*$/d' | wc -l)
c=$(cat $MODPATH/log/cachedir.log | sed '/^[[:space:]]*$/d' | wc -l)

newsize=$(du -sm /data | tr -cd '[0-9]')
data_size=$(($oldsize - $newsize))

# 更新统计信息
$MODPATH/crond/stats.sh

# 更新模块描述
if [ "$data_size" -lt 0 ]; then
	data_size=$(echo $data_size | tr -cd '[0-9]')
	echo "从模块开始运行到[ $(date '+%y年%m月%d日%T') ]，共清理空文件夹"$a"个，"$c"个应用缓存文件夹，本次运行储存空间增加了 "$data_size" MB。" >> $LOG_FILE
else
	echo "从模块开始运行到[ $(date '+%y年%m月%d日%T') ]，共清理空文件夹"$a"个，"$c"个应用缓存文件夹，本次运行储存空间释放了 "$data_size" MB。" >> $LOG_FILE
fi
